"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/communication-config.ts
var communication_config_exports = {};
__export(communication_config_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(communication_config_exports);

// lib/communication/resolveVoiceProfile.ts
function convertToneRuleToAssignmentRule(toneRule) {
  let scope = "app";
  if (toneRule.scope === "user") scope = "user";
  else if (toneRule.scope === "group") scope = "group";
  else if (toneRule.scope === "app") scope = "app";
  return {
    id: toneRule.id,
    profileId: toneRule.profileId,
    scope,
    targetId: toneRule.targetId,
    targetLabel: toneRule.targetLabel,
    channelScope: toneRule.channelScope,
    order: toneRule.order
  };
}

// lib/communication/store.ts
var cachedConfig = null;
var DEFAULT_BRAND_VOICE = {
  missionValues: ["student-centered", "equity-first"],
  communicationPillars: ["clarity", "support", "transparency"],
  sliders: {
    formality: 60,
    warmth: 70,
    directness: 65,
    energy: 60,
    detailLevel: 70,
    riskPosture: 50
  },
  style: {
    emojiAllowed: true,
    contractionsAllowed: true
  }
};
var DEFAULT_VOICE_PROFILES = [
  {
    id: "profile_institutional",
    name: "Institutional",
    description: "Default institutional voice profile",
    isDefault: true,
    brand: {
      typographyStyle: "system"
    },
    missionValues: ["student-centered", "equity-first"],
    communicationPillars: ["clarity", "support", "transparency"],
    characteristics: {
      formality: 60,
      warmth: 70,
      directness: 65,
      energy: 60,
      detailLevel: 70,
      riskPosture: 50
    },
    stylePreferences: {
      allowEmojis: true,
      allowContractions: true,
      useFirstPerson: false,
      allowLightHumor: false
    }
  }
];
var DEFAULT_PERSONALITY = {
  archetype: "guide",
  empathy: "high",
  enthusiasm: "balanced",
  humorAllowed: false,
  figurativeLanguage: true
};
var DEFAULT_TONE_RULES = [];
var DEFAULT_ASSIGNMENT_RULES = [];
var DEFAULT_CONFIG = {
  voiceProfiles: DEFAULT_VOICE_PROFILES,
  brand: DEFAULT_BRAND_VOICE,
  // Keep for backward compatibility
  personality: DEFAULT_PERSONALITY,
  assignmentRules: DEFAULT_ASSIGNMENT_RULES,
  toneRules: DEFAULT_TONE_RULES,
  // Legacy support
  updatedAt: (/* @__PURE__ */ new Date()).toISOString()
};
function migrateConfig(config) {
  if (config.assignmentRules && config.assignmentRules.length > 0) {
    return config;
  }
  if (config.toneRules && config.toneRules.length > 0) {
    const assignmentRules = config.toneRules.map(convertToneRuleToAssignmentRule);
    return {
      ...config,
      assignmentRules
      // Keep toneRules for backward compatibility during migration
    };
  }
  return {
    ...config,
    assignmentRules: []
  };
}
async function loadCommunicationConfig() {
  let config;
  if (cachedConfig) {
    config = cachedConfig;
  } else {
    config = { ...DEFAULT_CONFIG };
  }
  const migrated = migrateConfig(config);
  cachedConfig = migrated;
  return migrated;
}
async function saveCommunicationConfig(config, updatedBy) {
  const validationErrors = validateCommunicationConfig(config);
  if (validationErrors.length > 0) {
    throw new Error(`Validation failed: ${validationErrors.join(", ")}`);
  }
  const updatedConfig = {
    ...config,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy
  };
  cachedConfig = updatedConfig;
  return updatedConfig;
}
function validateCommunicationConfig(config) {
  const errors = [];
  if (!config.voiceProfiles || config.voiceProfiles.length === 0) {
    errors.push("At least one voice profile is required");
  } else {
    const defaultCount = config.voiceProfiles.filter((p) => p.isDefault).length;
    if (defaultCount === 0) {
      errors.push("Exactly one voice profile must be marked as default");
    } else if (defaultCount > 1) {
      errors.push("Only one voice profile can be marked as default");
    }
    config.voiceProfiles.forEach((profile, index) => {
      if (!profile.id || !profile.name) {
        errors.push(`Voice profile ${index + 1} must have id and name`);
      }
      if (profile.characteristics.formality < 0 || profile.characteristics.formality > 100) {
        errors.push(`Profile "${profile.name}": Formality must be between 0 and 100`);
      }
      if (profile.characteristics.warmth < 0 || profile.characteristics.warmth > 100) {
        errors.push(`Profile "${profile.name}": Warmth must be between 0 and 100`);
      }
      if (profile.characteristics.directness < 0 || profile.characteristics.directness > 100) {
        errors.push(`Profile "${profile.name}": Directness must be between 0 and 100`);
      }
      if (profile.characteristics.energy < 0 || profile.characteristics.energy > 100) {
        errors.push(`Profile "${profile.name}": Energy must be between 0 and 100`);
      }
      if (profile.characteristics.detailLevel < 0 || profile.characteristics.detailLevel > 100) {
        errors.push(`Profile "${profile.name}": Detail level must be between 0 and 100`);
      }
      if (profile.characteristics.riskPosture < 0 || profile.characteristics.riskPosture > 100) {
        errors.push(`Profile "${profile.name}": Risk posture must be between 0 and 100`);
      }
    });
  }
  if (config.brand && config.brand.sliders) {
    if (config.brand.sliders.formality < 0 || config.brand.sliders.formality > 100) {
      errors.push("Formality slider must be between 0 and 100");
    }
    if (config.brand.sliders.warmth < 0 || config.brand.sliders.warmth > 100) {
      errors.push("Warmth slider must be between 0 and 100");
    }
    if (config.brand.sliders.directness < 0 || config.brand.sliders.directness > 100) {
      errors.push("Directness slider must be between 0 and 100");
    }
    if (config.brand.sliders.energy < 0 || config.brand.sliders.energy > 100) {
      errors.push("Energy slider must be between 0 and 100");
    }
    if (config.brand.sliders.detailLevel < 0 || config.brand.sliders.detailLevel > 100) {
      errors.push("Detail level slider must be between 0 and 100");
    }
    if (config.brand.sliders.riskPosture < 0 || config.brand.sliders.riskPosture > 100) {
      errors.push("Risk posture slider must be between 0 and 100");
    }
  }
  const validArchetypes = ["mentor", "peer", "guide", "administrator", "professional", "counselor"];
  if (!validArchetypes.includes(config.personality.archetype)) {
    errors.push(`Personality archetype must be one of: ${validArchetypes.join(", ")}`);
  }
  const validEmpathy = ["low", "medium", "high"];
  if (!validEmpathy.includes(config.personality.empathy)) {
    errors.push(`Empathy must be one of: ${validEmpathy.join(", ")}`);
  }
  const validEnthusiasm = ["reserved", "balanced", "cheerful"];
  if (!validEnthusiasm.includes(config.personality.enthusiasm)) {
    errors.push(`Enthusiasm must be one of: ${validEnthusiasm.join(", ")}`);
  }
  const assignmentRules = config.assignmentRules || [];
  for (const rule of assignmentRules) {
    if (!rule.id) {
      errors.push("Assignment rules must have id");
    }
    if (!rule.scope || !["user", "group", "agent", "app"].includes(rule.scope)) {
      errors.push(`Assignment rule "${rule.id}" must have a valid scope (user, group, agent, or app)`);
    }
    if (!rule.targetId || !rule.targetLabel) {
      errors.push(`Assignment rule "${rule.id}" must have targetId and targetLabel`);
    }
    if (!rule.profileId) {
      errors.push(`Assignment rule "${rule.id}" must have a profileId`);
    }
    if (!config.voiceProfiles?.find((p) => p.id === rule.profileId)) {
      errors.push(`Assignment rule "${rule.id}" references a non-existent voice profile`);
    }
    if (typeof rule.order !== "number") {
      errors.push(`Assignment rule "${rule.id}" must have an order number`);
    }
  }
  const toneRules = config.toneRules || [];
  for (const rule of toneRules) {
    if (!rule.id) {
      errors.push("Tone rules must have id");
    }
    if (!rule.scope || !["app", "group", "user"].includes(rule.scope)) {
      errors.push(`Tone rule "${rule.id}" must have a valid scope (app, group, or user)`);
    }
    if (!rule.targetId || !rule.targetLabel) {
      errors.push(`Tone rule "${rule.id}" must have targetId and targetLabel`);
    }
    if (!rule.profileId) {
      errors.push(`Tone rule "${rule.id}" must have a profileId`);
    }
    if (!config.voiceProfiles?.find((p) => p.id === rule.profileId)) {
      errors.push(`Tone rule "${rule.id}" references a non-existent voice profile`);
    }
    if (typeof rule.order !== "number") {
      errors.push(`Tone rule "${rule.id}" must have an order number`);
    }
  }
  return errors;
}

// netlify/functions/communication-config.ts
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers,
      body: ""
    };
  }
  try {
    if (event.httpMethod === "GET") {
      const config = await loadCommunicationConfig();
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ config })
      };
    }
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const { config } = body;
      if (!config) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "config is required" })
        };
      }
      const validationErrors = validateCommunicationConfig(config);
      if (validationErrors.length > 0) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Validation failed", details: validationErrors })
        };
      }
      const updatedBy = "admin";
      const updatedConfig = await saveCommunicationConfig(config, updatedBy);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ config: updatedConfig })
      };
    }
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  } catch (error) {
    console.error("Communication config error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Failed to process communication config request" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

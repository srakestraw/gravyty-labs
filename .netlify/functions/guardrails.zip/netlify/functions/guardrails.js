"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/guardrails.ts
var guardrails_exports = {};
__export(guardrails_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(guardrails_exports);

// lib/guardrails/config.ts
var DEFAULT_GUARDRAILS = {
  fairness: {
    protectedAttributes: [
      "race_ethnicity",
      "gender_identity",
      "sexual_orientation",
      "religion",
      "national_origin",
      "disability_status",
      "age",
      "veteran_status",
      "first_gen",
      "low_income"
    ],
    allowProtectedUseForSupportPrograms: true,
    requireFairnessEvalForAutoAgents: true,
    bannedPhrases: [
      "low-quality student",
      "bad donor",
      "hopeless case"
    ]
  },
  dataScope: {
    allowedDomains: [
      "admissions",
      "student_success",
      "registrar",
      "career_services",
      "alumni_engagement",
      "advancement"
    ],
    excludeConfidentialNotes: true,
    disallowMentalHealthData: true,
    disallowConductRecords: true,
    channelContentRules: {
      email: "summary_ok",
      sms: "reminders_only",
      phone: "summary_ok"
    }
  },
  contactPolicy: {
    quietHours: {
      enabled: true,
      startTime: "21:00",
      endTime: "08:00",
      timezoneMode: "recipient"
    },
    quietPeriods: [],
    sensitiveDates: [],
    globalFrequencyCaps: {
      maxMessagesPerDay: 3,
      maxMessagesPerWeek: 10
    },
    perAgentFrequencyCapsDefault: {
      maxMessagesPer14Days: 2,
      escalationAfterUnansweredCount: 3
    }
  },
  actions: {
    defaults: {
      send_email: "human_review",
      send_sms: "human_review",
      send_phone_call: "blocked",
      create_task: "auto",
      create_internal_flag: "auto",
      change_status: "human_review",
      change_owner: "human_review"
    },
    perRoleOverrides: {}
  },
  logging: {
    requireActionLogging: true,
    requireDneCheckLogging: true,
    requireGuardrailCheckLogging: true,
    requireEvalStatusBeforeAuto: true
  }
};

// lib/guardrails/store.ts
var cachedConfig = null;
function convertLegacyConfig() {
  const legacy = DEFAULT_GUARDRAILS;
  return {
    fairness: {
      protectedAttributes: legacy.fairness.protectedAttributes,
      allowAttributeOverrides: legacy.fairness.allowProtectedUseForSupportPrograms,
      languageGuidelines: {
        avoidFraming: legacy.fairness.bannedPhrases,
        preferredFraming: []
        // Not in legacy config
      },
      fairnessEvalsEnabled: legacy.fairness.requireFairnessEvalForAutoAgents
    },
    privacy: {
      allowedDomains: legacy.dataScope.allowedDomains,
      sensitiveDomainsExcluded: [
        ...legacy.dataScope.excludeConfidentialNotes ? ["counseling_notes"] : [],
        ...legacy.dataScope.disallowMentalHealthData ? ["mental_health"] : [],
        ...legacy.dataScope.disallowConductRecords ? ["conduct_records"] : []
      ],
      emailPolicy: legacy.dataScope.channelContentRules.email === "summary_ok" ? "summary_only" : "no_sensitive",
      smsPolicy: legacy.dataScope.channelContentRules.sms === "reminders_only" ? "reminders_only" : "restricted",
      phonePolicy: legacy.dataScope.channelContentRules.phone === "summary_ok" ? "summary_only" : "restricted"
    },
    engagement: {
      quietHours: {
        enabled: legacy.contactPolicy.quietHours.enabled,
        startLocal: legacy.contactPolicy.quietHours.startTime,
        endLocal: legacy.contactPolicy.quietHours.endTime,
        timezone: legacy.contactPolicy.quietHours.timezoneMode === "recipient" ? "recipient" : "institution"
      },
      seasonalQuietPeriods: legacy.contactPolicy.quietPeriods.map((qp) => ({
        id: qp.id,
        label: qp.name,
        startDate: qp.startDate,
        endDate: qp.endDate
      })),
      holidayRules: legacy.contactPolicy.sensitiveDates.map((sd) => ({
        id: sd.id,
        label: sd.name,
        date: sd.date,
        scope: sd.appliesTo === "all" ? "global" : sd.appliesTo
      })),
      frequencyCaps: {
        globalMaxMessagesPerWeek: legacy.contactPolicy.globalFrequencyCaps.maxMessagesPerWeek,
        globalMaxMessagesPerDay: legacy.contactPolicy.globalFrequencyCaps.maxMessagesPerDay,
        perAgentDefaultMaxIn14Days: legacy.contactPolicy.perAgentFrequencyCapsDefault.maxMessagesPer14Days,
        maxUnansweredAttemptsBeforeEscalation: legacy.contactPolicy.perAgentFrequencyCapsDefault.escalationAfterUnansweredCount
      }
    },
    actions: {
      rules: Object.entries(legacy.actions.defaults).map(([actionKey, mode]) => ({
        actionKey,
        mode
      })),
      loggingRequired: legacy.logging.requireActionLogging,
      requireEvalBeforeAuto: legacy.logging.requireEvalStatusBeforeAuto
    },
    // Escalation rules will be loaded separately or from API
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function loadGuardrailsConfig() {
  if (cachedConfig) {
    return cachedConfig;
  }
  cachedConfig = convertLegacyConfig();
  return cachedConfig;
}
async function saveGuardrailsConfig(config, updatedBy) {
  const validationErrors = validateGuardrailsConfig(config);
  if (validationErrors.length > 0) {
    throw new Error(`Validation failed: ${validationErrors.join(", ")}`);
  }
  const updatedConfig = {
    ...config,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy
  };
  cachedConfig = updatedConfig;
  return updatedConfig;
}
function validateGuardrailsConfig(config) {
  const errors = [];
  if (config.fairness.protectedAttributes.some((attr) => !attr || attr.trim() === "")) {
    errors.push("Protected attributes cannot contain empty strings");
  }
  for (const period of config.engagement.seasonalQuietPeriods) {
    if (new Date(period.startDate) > new Date(period.endDate)) {
      errors.push(`Seasonal quiet period "${period.label}" has startDate after endDate`);
    }
  }
  if (config.engagement.frequencyCaps.globalMaxMessagesPerWeek <= 0) {
    errors.push("Global max messages per week must be positive");
  }
  if (config.engagement.frequencyCaps.globalMaxMessagesPerDay <= 0) {
    errors.push("Global max messages per day must be positive");
  }
  if (config.engagement.frequencyCaps.perAgentDefaultMaxIn14Days <= 0) {
    errors.push("Per-agent default max in 14 days must be positive");
  }
  if (config.engagement.frequencyCaps.maxUnansweredAttemptsBeforeEscalation <= 0) {
    errors.push("Max unanswered attempts before escalation must be positive");
  }
  if (config.engagement.quietHours.enabled) {
    if (config.engagement.quietHours.startLocal === config.engagement.quietHours.endLocal) {
      errors.push("Quiet hours start and end times cannot be equal when enabled");
    }
  }
  return errors;
}

// netlify/functions/guardrails.ts
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers,
      body: ""
    };
  }
  try {
    if (event.httpMethod === "GET") {
      const config = await loadGuardrailsConfig();
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ config })
      };
    }
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const { config } = body;
      if (!config) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "config is required" })
        };
      }
      const validationErrors = validateGuardrailsConfig(config);
      if (validationErrors.length > 0) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Validation failed", details: validationErrors })
        };
      }
      const updatedBy = "admin";
      const updatedConfig = await saveGuardrailsConfig(config, updatedBy);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ config: updatedConfig })
      };
    }
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  } catch (error) {
    console.error("Guardrails error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Failed to process guardrails request" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

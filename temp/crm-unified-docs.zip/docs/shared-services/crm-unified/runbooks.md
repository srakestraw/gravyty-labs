# Runbooks

## Seed CRM data
Goal: generate 2 fiscal years of seed data for demos.

Steps
1. Choose fiscal year start month (default: July)
2. Run seed generator:
   - officers: 10
   - constituents: 300-800
   - gifts: 2,000-6,000
   - interactions: 1,500-4,000
   - events: 25-60
3. Validate reports:
   - Lapsed donors should be >= 10% of prior FY donors

## Run synthetic AI enrichment
1. Enable AI enrichment flag
2. Run enrichment job for:
   - Interaction.summary
   - SentimentSignal.rationale
   - Task.recommendation_reason
   - Outreach message snippet
3. Validate guardrails:
   - No invented gifts or attendance

## Troubleshooting
- Empty lapsed donor report: increase lapsed-rate parameter in generator
- Queue is unhelpful: tune weighting for recency and engagement
- AI content feels generic: pass richer but safe cues (events attended, last gift recency, stated interests tags)

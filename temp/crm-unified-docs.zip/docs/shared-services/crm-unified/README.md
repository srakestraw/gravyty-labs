# CRM Unified - Mock CRM Service

CRM Unified is a mock advancement CRM service for GravytyLabs demos and testing. It models a canonical advancement CRM that unifies the common concepts across Salesforce and Blackbaud (Contacts or Constituents, Gifts, Activities, Events, Portfolios).

## Quick start
- Run the service in seed mode (2 years of data)
- Use the UI to:
  - Build a portfolio using propensity, events, and sentiment
  - Work an outreach queue with recommended next actions
  - Identify lapsed donors (gave last FY, not this FY)

Links:
- [Context](./context.md)
- [Contracts](./contracts.md)
- [Architecture](./architecture.md)
- [APIs and events](./apis-and-events.md)
- [Runbooks](./runbooks.md)

---

## PRD - Advancement CRM Mock (Unified Salesforce + Blackbaud)

### Document info
- Product or Module: GravytyLabs - Shared Services - CRM Unified
- Owner: Product
- Users: Advancement Officers, Managers (optional)
- Status: Draft
- Last updated: 2025-12-23

### Problem statement
We need a mock CRM inside GravytyLabs that represents a common advancement data model that unifies the shape of Salesforce (Accounts, Contacts, Activities, Opportunities) and Blackbaud (Constituents, Gifts, Actions, Campaigns) to support advancement officer workflows. This mock CRM must include a usable UI, two years of realistic seed data, and AI-driven synthetic data generation aligned to the model.

### Goals and success criteria

Goals
1. Provide a standard, canonical advancement CRM data model (CDM) that can map to Salesforce and Blackbaud concepts.
2. Provide a working CRM front-end supporting core workflows:
   - Portfolio building using propensity plus engagement signals (events plus sentiment)
   - Outreach management and prioritization (right person, right message, right time)
   - Lapsed donor identification (donated last year, not this year)
3. Provide 2 years of seed data sufficient to demo and test workflows.
4. Provide a synthetic data generation pipeline that:
   - Produces structured records matching the CDM
   - Uses AI only where it adds value (narrative fields, realistic variation, notes, sentiment reasons)

Success criteria (MVP)
- A user can build a portfolio of 50-150 constituents using filters for propensity, event engagement, and sentiment.
- A user can view and work an outreach queue with recommended next action and message suggestion.
- A user can generate a lapsed donor list for the current fiscal year vs prior fiscal year.
- Seed dataset includes:
  - At least 300 constituents, 30 organizations, 10 officers
  - At least 2,000 gifts across 2 years
  - At least 1,500 interactions, tasks, notes
  - At least 25 events with attendance history
  - Sentiment signals attached to interactions for a meaningful subset (>= 30%)

### Non-goals (MVP)
- Full fidelity Salesforce or Blackbaud feature parity
- Real integrations or bidirectional sync
- Complex gift accounting, GL, receipting, soft credits, matching gifts (beyond minimal placeholders)
- Full territory management and moves management beyond basic portfolio assignment and tasks
- Permissioning beyond basic role-based access (Admin vs Officer)

### Primary user stories (MVP)

US1 - Portfolio building
As an advancement officer, I need to build a portfolio based on propensity to give and engagement signals (events and sentiment) so that I can focus on the highest likelihood donors.

Acceptance criteria
- Filter constituents by:
  - Propensity score range
  - Last gift date (relative, eg last 30, 90, 365 days)
  - Total giving last FY vs this FY
  - Event attendance count and recency
  - Sentiment trend (positive, neutral, negative) and recency
- Save a portfolio and assign it to myself
- Explainability: show top drivers (eg "Attended 3 events in last 90 days", "Positive sentiment from last call note", "Upward giving trend last FY")

US2 - Outreach prioritization
As an advancement officer, I need to manage and prioritize outreach to my portfolio - right person, right message, right time - so that I can execute my weekly plan efficiently.

Acceptance criteria
- A queue that lists portfolio constituents with:
  - Priority score (0-100)
  - Recommended next action (call, email, meeting request, invite to event)
  - Recommended message snippet (AI-generated) and rationale
  - Best next time window (simple heuristics are fine)
- Ability to create and complete tasks and log outcomes (contacted, left voicemail, email sent, meeting scheduled)
- "Today's plan" view that surfaces 10-25 recommended actions

US3 - Lapsed donors
As an advancement officer, I need to identify people who donated last year but did not donate this year so that I can run retention outreach.

Acceptance criteria
- "Lapsed Donors" report:
  - Donors with gifts in prior FY but zero gifts in current FY
  - Include prior FY total, last gift date, last gift amount, engagement signals
- One-click add to portfolio or create tasks in bulk (eg create 25 tasks)

### Solution overview
We are building a mock "Unified Advancement CRM" service with:
1. Canonical Data Model (CDM) representing unified Salesforce plus Blackbaud concepts
2. UI to browse constituents, portfolios, interactions, giving, and events
3. Seed data for 2 fiscal years
4. Synthetic data generator (structured plus AI enrichment)

Design principles
- Canonical first - model the common shape, not either vendor's quirks
- Explainability by default - every score or recommendation must show drivers
- Seed data should be demo-ready - realistic patterns, not uniform randomness
- Keep the data model stable - expand via optional tables, not breaking changes

For detailed entity definitions, endpoints, and generation flow, see the linked docs above.

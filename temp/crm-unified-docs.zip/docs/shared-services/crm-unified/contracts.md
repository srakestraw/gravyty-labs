# Contracts

This document defines the canonical data model (CDM) and the API contracts that the CRM Unified service guarantees.

## Canonical Data Model (CDM)

### Entities (MVP)
- Person
- Organization
- Relationship
- Affiliation
- Gift
- Interaction
- Task
- Event
- EventParticipation
- SentimentSignal
- PropensityScore
- Portfolio
- PortfolioMember

### Notes on unification
- Salesforce Contact + Blackbaud Constituent -> Person
- Salesforce Account (Household or Org) + Blackbaud Org patterns -> Organization (org_type differentiates)
- Salesforce Activities and Tasks + Blackbaud Actions -> Interaction and Task
- Gifts -> Gift
- Events -> Event and EventParticipation

## API contract overview

### List and search
- GET /people?filters...
- GET /organizations?filters...
- GET /events?filters...

### 360 views and rollups
- GET /people/:id (includes giving rollups, engagement, sentiment trend)
- GET /people/:id/gifts
- GET /people/:id/interactions
- GET /people/:id/tasks

### Portfolios
- GET /portfolios
- POST /portfolios
- POST /portfolios/:id/members

### Outreach queue
- GET /queue/outreach?officer_id=...

### Reports
- GET /reports/lapsed-donors?fy=...

## SLOs (mock defaults)
- Availability: best effort (dev and demo)
- Latency: < 500ms for list queries with <= 1k constituents
- Compatibility: stable CDM fields, additive changes only

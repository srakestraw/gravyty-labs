# APIs and events

## REST endpoints (recommended)

### People
- GET /people
- GET /people/:id

### Portfolios
- GET /portfolios
- POST /portfolios
- POST /portfolios/:id/members

### Outreach queue
- GET /queue/outreach?officer_id=...

### Tasks and interactions
- POST /tasks
- POST /interactions

### Reports
- GET /reports/lapsed-donors?fy=...

## Events (optional)
If you add an event bus later, keep event names aligned to the CDM:
- crm.person.created
- crm.gift.created
- crm.interaction.logged
- crm.task.created
- crm.portfolio.updated

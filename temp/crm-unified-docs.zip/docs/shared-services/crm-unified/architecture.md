# Architecture

## Overview
CRM Unified is a shared-service mock that provides a canonical advancement CRM dataset and a thin API surface for GravytyLabs apps.

## Components
- Storage: SQLite or Postgres (dev selectable)
- Seed generator: deterministic structured generator
- Synthetic generator: AI enrichment pass for narrative fields only
- Scoring:
  - PropensityScore stored and time-versioned
  - Priority score computed from propensity, engagement, recency, lapsed status

## Data generation flow
1. Generate structured entities (no AI)
2. Compute rollups (FY giving totals, last gift, last touch)
3. AI enrichment (optional):
   - Interaction summaries
   - Sentiment rationale
   - Recommendation reasons
   - Suggested outreach message snippet

## Guardrails
- AI enrichment may only reference cues passed from structured data
- Do not invent gifts, amounts, attendance, or relationships

## Integration points
- GravytyLabs UI modules consume the provider interface
- Future: mapping adapters to real Salesforce and Blackbaud connectors

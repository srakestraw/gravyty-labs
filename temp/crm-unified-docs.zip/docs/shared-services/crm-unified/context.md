# Context

## When to use CRM Unified
Use CRM Unified when you need a reliable, demo-friendly advancement CRM dataset and interface inside GravytyLabs to power:
- Portfolios and officer worklists
- Outreach queue and task management
- Lapsed donor reporting
- Agentic and assistant workflows that depend on CRM-shaped data

## When not to use it
Do not use CRM Unified for:
- Production constituent management
- Financially authoritative gift accounting
- System of record synchronization

## Which domains or apps use it
- GravytyLabs mock apps
- Advancement assistants and workflows
- Demo environments and automated testing

## Alternatives
- Salesforce Education Cloud or Nonprofit Success Pack (system of record)
- Blackbaud Raiser's Edge NXT (system of record)
- Institution-specific CRM or advancement database
